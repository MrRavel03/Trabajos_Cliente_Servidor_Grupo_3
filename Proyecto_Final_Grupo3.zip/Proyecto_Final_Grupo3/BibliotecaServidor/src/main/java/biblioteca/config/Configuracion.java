package biblioteca.config;

public class Configuracion {

    public static final double COSTO_MULTA_POR_DIA = 500.0;
    public static final int DIAS_PRESTAMO_GRATIS = 7;

}
